from django.contrib import admin
from . models import Refferal

# Register your models here.
admin.site.register(Refferal)