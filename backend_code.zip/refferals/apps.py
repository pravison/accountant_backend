from django.apps import AppConfig


class RefferalsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'refferals'
