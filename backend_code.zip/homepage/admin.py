from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Company)
admin.site.register(About_us)
admin.site.register(Feature)
admin.site.register(Service)
admin.site.register(Question)
admin.site.register(Testimonial)
admin.site.register(Team)
admin.site.register(Customer)
admin.site.register(Pricing)
admin.site.register(Social_Links)
admin.site.register(Contact_us)